//
//  ViewController.swift
//  SimplifiedCalculator
//
//  Created by 亷博旭 on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var formula: UILabel!
    
    var currentnum:String = ""
    
    var formulalabel:String = ""{
        didSet{
            formula.text = String(formulalabel)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func persent(_ sender: Any) {
        
    }
    @IBAction func PN(_ sender: Any) {
        let tmp = currentnum
        if Double(currentnum) ?? 0 < 0{
            currentnum.replacingOccurrences(of: "-", with:"")
        }
        else{
            currentnum = "-" + currentnum
        }
        formulalabel.replacingOccurrences(of: tmp, with: currentnum)
    }
    @IBAction func AC(_ sender: UIButton) {
        formulalabel = ""
        result.text = "0"
        currentnum = ""
    }
    
    @IBAction func float(_ sender: UIButton) {
        if !currentnum.contains("."){
            if currentnum == ""{
                currentnum.append("0.")
                formulalabel.append("0.")
            }
            else{
                currentnum.append(".")
                formulalabel.append(".")
            }
        }

    }
    @IBAction func one(_ sender: UIButton) {
        formulalabel.append(sender.currentTitle!)
        currentnum.append(sender.currentTitle!)
    }
    
    @IBAction func plus(_ sender: UIButton) {
        if formulalabel != ""{
            formulalabel.append(" + ")
        }
        else{
            formulalabel.append("0 + ")
        }
        currentnum = ""
        sender.setTitleColor(.orange, for: .highlighted)
    }
    
    @IBAction func minus(_ sender: UIButton) {
        if formulalabel != ""{
            formulalabel.append(" - ")
        }
        else{
            formulalabel.append("0 - ")
        }
        currentnum = ""
        sender.setTitleColor(.orange, for: .highlighted)
    }
    
    @IBAction func multply(_ sender: UIButton) {
        if formulalabel != ""{
            formulalabel.append(" * ")
        }
        else{
            formulalabel.append("0 * ")
        }
        currentnum = ""
        sender.setTitleColor(.orange, for: .highlighted)
    }
    
    @IBAction func devide(_ sender: UIButton) {
        if formulalabel != ""{
            formulalabel.append(" / ")
        }
        else{
            formulalabel.append("0 / ")
        }
        currentnum = ""
        sender.setTitleColor(.orange, for: .highlighted)
    }
    
    @IBAction func amount(_ sender: UIButton) {
        let Count = NSExpression(format:formulalabel)
        currentnum = String(Count.expressionValue(with: nil, context: nil) as! Double)
        result.text = currentnum
    }
    
}

